package com.cp.flightmanagementsystem.exception;

public class NumberFormatE extends Exception {
	public NumberFormatE(String msg)
	{
		super(msg);
	}

}
