package com.cp.flightmanagementsystem.exception;

public class IDNotFoundException extends Exception {
	public IDNotFoundException()
	{
		System.out.println("Enter valid id");
	}

}
