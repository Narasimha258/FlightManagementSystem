package com.cp.flightmanagementsystem.exception;

public class ScheduledFlightServiceException extends Exception {
	
	  public  ScheduledFlightServiceException(String s) {
		  
		      super(s);
	  }
	  

}
