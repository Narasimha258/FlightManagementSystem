package com.cp.flightmanagementsystem.exception;

public class UserListNotFoundException extends Exception {
	public UserListNotFoundException()
	{
		System.out.println("UserList Empty");
	}

}
