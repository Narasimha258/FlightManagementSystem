package com.cp.flightmanagementsystem.exception;

public class DeleteFlightException extends Exception {
	
	   public DeleteFlightException(String string) {
		   
		    super(string);
	   }

}
