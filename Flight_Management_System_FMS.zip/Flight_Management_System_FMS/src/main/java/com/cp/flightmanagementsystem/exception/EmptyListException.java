package com.cp.flightmanagementsystem.exception;

public class EmptyListException extends Exception {
	
	   public EmptyListException(String string) {
		   
		     super(string);
	    }

}
